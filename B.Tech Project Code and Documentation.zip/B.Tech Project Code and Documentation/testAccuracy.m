function [correctlyPredictedFinal,totalNonZero]=testAccuracy(recommended,dataset,index)
    recommended=sortrows(recommended,1);
    items=size(recommended,1);
    correctlyPredicted=zeros(10,1);
    for i=1:10
        if index==1
            for j=1:items
                if (recommended(j)<36 && dataset(recommended(j,1),1)~=0)
                    correctlyPredicted(i,1)=correctlyPredicted(i,1)+1;
                end
            end
            totalNonZero=nnz(dataset((1:35),:));
        else if index==2
                for j=1:items
                    if (recommended(j)<71 && dataset(recommended(j,1),1)~=0 && recommended(j)>35)
                        correctlyPredicted(i,1)=correctlyPredicted(i,1)+1;
                    end
                end
                totalNonZero=nnz(dataset((36:70),:));
            else if index==3
                    for j=1:items
                        if (recommended(j)<106 && dataset(recommended(j,1),1)~=0 && recommended(j)>70)
                            correctlyPredicted(i,1)=correctlyPredicted(i,1)+1;
                        end
                    end
                    totalNonZero=nnz(dataset((71:105),:));
                else if index==4
                    for j=1:items
                        if (recommended(j)<141 && dataset(recommended(j,1),1)~=0 && recommended(j)>105)
                            correctlyPredicted(i,1)=correctlyPredicted(i,1)+1;
                        end
                    end
                    totalNonZero=nnz(dataset((106:140),:));
                    else if index==5
                        for j=1:items
                            if (recommended(j)<176 && dataset(recommended(j,1),1)~=0 && recommended(j)>140)
                                correctlyPredicted(i,1)=correctlyPredicted(i,1)+1;
                            end
                        end
                        totalNonZero=nnz(dataset((141:175),:));
                        else if index==6
                            for j=1:items
                                if (recommended(j)<211 && dataset(recommended(j,1),1)~=0 && recommended(j)>175)
                                    correctlyPredicted(i,1)=correctlyPredicted(i,1)+1;
                                end
                            end
                            totalNonZero=nnz(dataset((176:210),:));
                            else if index==7
                                for j=1:items
                                    if (recommended(j)<246 && dataset(recommended(j,1),1)~=0 && recommended(j)>210)
                                        correctlyPredicted(i,1)=correctlyPredicted(i,1)+1;
                                    end
                                end
                                totalNonZero=nnz(dataset((211:245),:));
                                else if index==8         
                                    for j=1:items
                                        if (recommended(j)<281 && dataset(recommended(j,1),1)~=0 && recommended(j)>245)
                                            correctlyPredicted(i,1)=correctlyPredicted(i,1)+1;
                                        end
                                    end
                                    totalNonZero=nnz(dataset((246:280),:));
                                    else if index==9         
                                        for j=1:items
                                            if (recommended(j)<316 && dataset(recommended(j,1),1)~=0 && recommended(j)>280)
                                                correctlyPredicted(i,1)=correctlyPredicted(i,1)+1;
                                            end
                                        end
                                        totalNonZero=nnz(dataset((281:315),:));
                                        else         
                                            for j=1:items
                                                if (recommended(j)<351 && dataset(recommended(j,1),1)~=0 && recommended(j)>315)
                                                    correctlyPredicted(i,1)=correctlyPredicted(i,1)+1;
                                                end
                                            end
                                            totalNonZero=nnz(dataset((316:350),:));
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
    correctlyPredictedFinal=correctlyPredicted(index,1);
end