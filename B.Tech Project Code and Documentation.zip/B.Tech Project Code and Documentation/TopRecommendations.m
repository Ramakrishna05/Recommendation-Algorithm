function recommendedItems=TopRecommendations(Ratings,Similarity)
    items=size(Ratings,1);
    users=size(Ratings,2);
    similarItemsRatings=zeros(items);
    targetUser=randi(users);
    display(targetUser);
    targetUserItems=Ratings(:,targetUser);
    display(targetUserItems);
    k=1;
    missedItems=zeros(1,items);
    for i=1:items
        if targetUserItems(i)==0
            missedItems(k)=i;
            similarItemsRatings(k,:)=Similarity(i,:);
            k=k+1;
        end
    end
    recommendations=zeros(1,size(similarItemsRatings,1));
    %display(similarItems);
    for i=1:k-1
        recommendations(i)=max(similarItemsRatings(i,:));
        recommendedItems=find(Similarity(missedItems(i),:)==recommendations(1));
        %recommendedItems;
    end
end