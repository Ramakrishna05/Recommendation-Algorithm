function numerator=knn_numerator(similarity,data,neighbors)
    users=size(data,1);
    similarityWithUserId=zeros(users,2);
    for i=1:users
        similarityWithUserId(i,1)=similarity(i);
        similarityWithUserId(i,2)=i;
    end
    sortedSimilarity=flipud(sortrows(similarityWithUserId,1));
    temp=0;
    for i=1:neighbors
        temp=temp+(sortedSimilarity(i,1)*data(sortedSimilarity(i,2)));
    end
    numerator=temp;
end