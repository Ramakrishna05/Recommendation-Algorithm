function missRatings=missValues(Dataset)
    range=size(Dataset,1)*size(Dataset,2)+1;
    missRatings=Dataset;
    randomMissing=randi(range,[20,1]);
    randomMissingRange=size(randomMissing,1);
    for i=1:randomMissingRange
        missRatings(randomMissing(i))=0;
    end
end