function DrawPlot()
    users=randi([1,670],[1,30]);
    %users=users(:,(2:size(users,2)-1));
    %display(neighbours);
    itr=size(users,2);
    accuracy_cosine=zeros(1,itr);
    accuracy_adjusted=zeros(1,itr);
    accuracy_pearson=zeros(1,itr);
    %dataset=csvread('ratings.csv');
    %dataset=transformDataset(dataset);
    %[users,number]=maxRatings(dataset);
    for i=1:itr
        accuracy_cosine(1,i)=Recommendation_Algorithm_Users(users(1,i));
        accuracy_adjusted(1,i)=Recommendation_Algorithm_Users_Adjusted(users(1,i));
        accuracy_pearson(1,i)=Recommendation_Algorithm_Users_Pearson(users(1,i));
    end
    figure
    plot(users,accuracy_cosine,'r.:',users,accuracy_adjusted,'b*-.',users,accuracy_pearson,'g+');
    title('Top N Recommendation Algorithm With Items Similarity');
    xlabel('User Id');
    ylabel('Accuracy');
    legend('Cosine Similarity','Adjusted Cosine Similarity','Pearson Similarity');
end