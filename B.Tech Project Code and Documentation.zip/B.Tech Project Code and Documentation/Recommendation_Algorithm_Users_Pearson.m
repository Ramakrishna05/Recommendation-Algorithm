function [precision,recall,f_one]=Recommendation_Algorithm_Users_Pearson()
    tic
    dataset=csvread('ratings.csv');
    dataset=transformDataset(dataset);
    %display(size(dataset,1));
    %display(size(dataset,2));
    [userId,maxItems]=maxRatings(dataset);
    %dataset=transpose(dataset);
    users=size(dataset,1);
    items=size(dataset,2);
    correctlyPredicted=0;
    threshold=0;
    % 10 fold cross validataion %
    targetUserItemsOriginal=dataset(userId,:);
    similarity_users=Similarity_Pearson(dataset);
    for itr=1:10
        k=1;
        cvdataset=createDataset(itr,dataset);
        for i=1:items
            %if targetUserItems(i)==0
                %display(i);
                similarityForThatUser=similarity_users(:,i);
                %display(similarityForThatItem);
                for j=1:items
                    if similarityForThatUser(j)>threshold
                        recommendedItems(k,1)=j;
                        recommendedItems(k,2)=similarityForThatUser(j);
                        k=k+1;
                    end
                end
                %display(recommendedItems);
            %end
        end
        recommendedItems=sortrows(recommendedItems,2);
        %display(recommendedItems);
        k=size(recommendedItems,1);
        x=1;
        while k>1
            %if cvdataset(recommendedItems(k,1),userId)==0
                %display(Dataset(recommendedItems(k,1),userId));
                recommendedItemsFinal(x,1)=recommendedItems(k,1);
                recommendedItemsFinal(x,2)=recommendedItems(k,2);
                x=x+1;
            %end
            k=k-1;
        end
        recommendedItemsFinal=flipud(sortrows(recommendedItemsFinal,2));
        k=size(recommendedItemsFinal,1);
        %display(recommendedItemsFinal);
        recommendedItemsFinalSorted=zeros(items,2);
        for i=1:k
            if recommendedItemsFinalSorted(recommendedItemsFinal(i,1),1)==0
                recommendedItemsFinalSorted(recommendedItemsFinal(i,1),1)=recommendedItemsFinal(i,1);
                recommendedItemsFinalSorted(recommendedItemsFinal(i,1),2)=recommendedItemsFinal(i,2);
            end
        end
        recommendedItemsFinalSorted=sortrows(recommendedItemsFinalSorted,2);
        recommendedItemsFinalSorted=flipud(recommendedItemsFinalSorted);
        %display(recommendedItemsFinalSorted);
        z=1;
        final_rows=size(recommendedItemsFinalSorted,1);
        for p=1:final_rows
            if recommendedItemsFinalSorted(p,1)~=0
                recommend(z,1)=recommendedItemsFinalSorted(p,1);
                recommend(z,2)=recommendedItemsFinalSorted(p,2);
                z=z+1;
            end
        end
        %display(recommend);
        correctlyPredicted=correctlyPredicted+testAccuracy_New(recommend,targetUserItemsOriginal);
    end
    precision=(correctlyPredicted/(size(dataset,1)*10))*100;
    rated_items=size(find(targetUserItems),1);
    recall=(correctlyPredicted/(rated_items*10))*100;
    f_one=(2*recall*precision)/(recall+precision);
    toc
end