function DrawPlot()
    neighbours=linspace(0,100,21);
    neighbours=neighbours(:,(2:size(neighbours,2)-1));
    %display(neighbours);
    itr=size(neighbours,2);
    accuracy_cosine=zeros(1,itr);
    accuracy_adjusted=zeros(1,itr);
    accuracy_pearson=zeros(1,itr);
    for i=1:itr
        accuracy_cosine(1,i)=Knn_Algorithm(neighbours(i));
        accuracy_adjusted(1,i)=Knn_Algorithm_Adjusted(neighbours(i));
        accuracy_pearson(1,i)=Knn_Algorithm_Pearson(neighbours(i));
    end
    figure
    plot(neighbours,accuracy_cosine,'r.:',neighbours,accuracy_adjusted,'b*-.',neighbours,accuracy_pearson,'g+');
    title('KNN Algorithm With Items');
    xlabel('No.of Neighbours');
    ylabel('Accuracy');
    legend('Cosine Similarity','Adjusted Cosine Similarity','Pearson Similarity');
end