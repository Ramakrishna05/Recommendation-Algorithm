function denominator=knn_denominator(similarity,data,n)
    items=size(data,1);
    similarityWithItemId=zeros(items,2);
    for i=1:items
        similarityWithItemId(i,1)=similarity(i);
        similarityWithItemId(i,2)=i;
    end
    sortedSimilarity=flipud(sortrows(similarityWithItemId,1));
    temp=0;
    for i=1:n
        temp=temp+data(sortedSimilarity(i,2));
    end
    denominator=temp;
end