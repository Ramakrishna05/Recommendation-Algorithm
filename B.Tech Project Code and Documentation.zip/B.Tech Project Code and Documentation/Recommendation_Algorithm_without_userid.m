function recommend=Recommendation_Algorithm_without_userid()
    dataset=csvread('mobileDataset.csv');
    Dataset=transpose(dataset);
    %display(Dataset);
    items=size(Dataset,1);
    %users=size(Dataset,2);
    %recommendedItemsFinal=zeros(items,2);
    %recommendedItemsFinalSorted=zeros(items,2);
    %recommendedItems=zeros(items,2);
    threshold=0.45;
    k=1;
    %display(Dataset);
    similarItems=Similarity_Cosine_new(Dataset);
    %display(similarItems);
    targetUserItems=zeros(items,1);
    for i=1:items
        if targetUserItems(i)==0
            %display(i);
            similarityForThatItem=similarItems(:,i);
            %display(similarityForThatItem);
            for j=1:items
                if similarityForThatItem(j)>threshold
                    recommendedItems(k,1)=j;
                    recommendedItems(k,2)=similarityForThatItem(j);
                    k=k+1;
                end
            end
            %display(recommendedItems);
        end
    end
    recommendedItems=sortrows(recommendedItems,2);
    %display(recommendedItems);
    k=size(recommendedItems,1);
    x=1;
    while k>0
        %display(Dataset(recommendedItems(k,1),UserID));
        recommendedItemsFinal(x,1)=recommendedItems(k,1);
        recommendedItemsFinal(x,2)=recommendedItems(k,2);
        x=x+1;
        k=k-1;
    end
    %display(recommendedItemsFinal);
    k=size(recommendedItemsFinal,1);
    for i=1:k
        %if recommendedItemsFinalSorted(recommendedItemsFinal(i,1),1)==0
        recommendedItemsFinalSorted(recommendedItemsFinal(i,1),1)=recommendedItemsFinal(i,1);
        recommendedItemsFinalSorted(recommendedItemsFinal(i,1),2)=recommendedItemsFinal(i,2);
        %end
    end
    %display(recommendedItemsFinalSorted);
    recommendedItemsFinalSorted=sortrows(recommendedItemsFinalSorted,2);
    recommendedItemsFinalSorted=flipud(recommendedItemsFinalSorted);
    final_rows=size(recommendedItemsFinalSorted,1);
    index=1;
    for i=1:final_rows
        if (recommendedItemsFinalSorted(i,1)~=0 && recommendedItemsFinalSorted(i,2)~=0)
            recommend(index,1)=recommendedItemsFinalSorted(i,1);
            recommend(index,2)=recommendedItemsFinalSorted(i,2);
            index=index+1;
        end
    end
    % Top Ten items%
    topN=zeros(30,1);
    for i=1:30
        if recommendedItemsFinalSorted(i,1)~=0
            topN(i,1)=int64(recommendedItemsFinalSorted(i,1));
            %topN(i,2)=recommendedItemsFinalSorted(i,2)*100;
        end
    end
    %writing into text file%
    fileId=fopen('output_without_uid.txt','w');
    fprintf(fileId,'%d\n',topN);
    fclose(fileId);
end