function correctlyPredicted=testAccuracy_New(recommended,dataset)
    recommended=sortrows(recommended,1);
    items=size(recommended,1);
    correctlyPredicted=0;
    for i=1:items
        if dataset(recommended(i,1),1)~=0
            correctlyPredicted=correctlyPredicted+1;
        end
    end
end