function [uid,max]=maxRatings(dataset)
    %dataset=csvread('ratings.csv');
    %dataset=transformDataset(dataset);
    users=size(dataset,1);
    uid=1;
    max=0;
    for i=1:users
        particularUserItems=dataset(i,:);
        if nnz(particularUserItems)>=max
            uid=i;
            max=nnz(particularUserItems);
        end
    end
end