function cos_similarity = Similarity_Cosine(Dataset)
    items=size(Dataset,1);
    %users=size(Dataset,2);
    cos_similarity=zeros(items,items);
    for i=1:items
        j=i+1;
        temp1=Dataset(i,:);
        %display(temp1);
        display(i);
        while j<items+1
            temp2=Dataset(j,:);
            %display(temp2);
            numerator=sum(temp1.*temp2);  % Ai * Bi for i from 1 to n where n is number of users rated the items A and B and Ai and Bi are the individual ratings
            denominator=(sqrt(sum(temp1.^2)))*(sqrt(sum(temp2.^2)));
            cos_similarity(i,j)=numerator/denominator;
            display(cos_similarity(i,j));
            j=j+1;
        end
    end