function PlotBarGraph(accuracies,names)
    figure('name','Accuracies');
    ylim([0,100]);
    bar(accuracies);
    set(Accuracies,'xticklabel',names);
end