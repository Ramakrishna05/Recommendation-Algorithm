function [precision,recall,f_one]=Knn_Algorithm_Pearson(neighbours)
    tic
    dataset=csvread('ratings.csv');
    dataset=transformDataset(dataset);
    %display(size(dataset,1));
    %display(size(dataset,2));
    [userId,maxItems]=maxRatings(dataset);
    users=size(dataset,1);
    items=size(dataset,2);
    correctlyPredicted=0;
    % 10 fold cross validataion %
    targetUserItems=dataset(userId,:);
    %similarity_users=Similarity_Pearson(dataset);
    for itr=1:10
        k=1;
        cvdataset=createDataset(itr,dataset);
        %display(size(cvdataset));
        if userId<=users
            similarity_users=Similarity_Pearson(cvdataset);
            %targetUserItems=dataset(userId,:);
            for i=1:items
                    numerator=knn_numerator(similarity_users(userId,:),cvdataset(:,i),neighbours);
                    denominator=knn_denominator(similarity_users(userId,:),cvdataset(:,i),neighbours);
                    recommendedItems(k,1)=i;
                    recommendedItems(k,2)=numerator/denominator;
                    if isnan(recommendedItems(k,2))
                        recommendedItems(k,2)=0;
                    end
                    k=k+1;
            end
        end
        recommendedItemsFinal=sortrows(recommendedItems,2);
        %recommendedItemsFinal=recommendedItemsFinal((1:items),:);
        recommendedItemsFinalSorted=flipud(recommendedItemsFinal);
        final_rows=size(recommendedItemsFinalSorted,1);
        index=1;
        for x=1:final_rows
            if (recommendedItemsFinalSorted(x,1)~=0 && recommendedItemsFinalSorted(x,2)~=0)
                recommend(index,1)=recommendedItemsFinalSorted(x,1);
                recommend(index,2)=recommendedItemsFinalSorted(x,2);
                index=index+1;
            end
        end
        correctlyPredicted=correctlyPredicted+testAccuracy_New(recommend,targetUserItems);
        %display(recommend);
    end
    precision=(correctlyPredicted/(size(dataset,2)*10))*100;
    rated_items=size(find(targetUserItems),1);
    recall=(correctlyPredicted/rated_items*10)*100;
    f_one=(2*recall*precision)/(recall+precision);
    toc
end