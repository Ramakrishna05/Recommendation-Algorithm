function adjusted_similarity = Similarity(Dataset)
    items=size(Dataset,1);
  
    users=size(Dataset,2);
   
    adjusted_similarity=zeros(items,items);
 
    for i=1:items
        for j=1:items
            
                %display(j);
                %display(i);
            p1=Dataset(i,:);
            p2=Dataset(j,:);
            meanp1=sum(p1)/users;
            meanp2=sum(p2)/users;
            %display(meanp3);
            modifiedp1=p1-meanp1;
            %display(modifiedp1);
      
            modifiedp2=p2-meanp2;
            num=sum(modifiedp1.*modifiedp2);
            %display(num);
            den=(sqrt(sum(modifiedp1.^2)))*(sqrt(sum(modifiedp2.^2)));
            %display(den);
            adjusted_similarity(i,j)=num/den;
            %display(adjusted_similarity(i,j));
           
            if adjusted_similarity(i,j)<0
                adjusted_similarity(i,j)=-1*adjusted_similarity(i,j);
            end
            adjusted_similarity(i,i)=0;
            if isnan(adjusted_similarity(i,j))
                adjusted_similarity(i,j)=0;
            end
        end
    end
end

