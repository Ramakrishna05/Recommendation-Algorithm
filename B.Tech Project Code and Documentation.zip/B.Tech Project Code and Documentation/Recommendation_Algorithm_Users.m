function recommend=Recommendation_Algorithm_Users(UserID)
    tic
    dataset=xlsread('ratings.xlsx');
    Dataset=transformDataset(dataset);
    %Dataset=transpose(Dataset);
    %display(Dataset);
    items=size(Dataset,2);
    users=size(Dataset,1);
    %display(users);
    %display(items);
    %recommendedItemsFinal=zeros(items,2);
    %recommendedItemsFinalSorted=zeros(items,2);
    %recommendedItems=zeros(items,2);
    threshold=0.45;
    k=1;
    %display(Dataset);
    if UserID<=users
        targetUserItems=Dataset(UserID,:);
    end
    similarUsers=Similarity_Cosine_new(Dataset);
    similarityForThatUser=similarUsers(UserID,:);
    %display(similarItems);
    for i=1:users
        if similarityForThatUser(i)>threshold
            %display(i);
            %display(similarityForThatItem);
            for j=1:items
                if targetUserItems(j)==0
                    if Dataset(i,j)~=0
                        recommendedItems(k,1)=j;
                        recommendedItems(k,2)=similarityForThatUser(i);
                        k=k+1;
                    end
                end
            end
            %display(recommendedItems);
        end
    end
    recommendedItems=sortrows(recommendedItems,2);
    %display(recommendedItems);
    k=size(recommendedItems,1);
    x=1;
    while k>1
        if Dataset(recommendedItems(k,1),UserID)==0
            %display(Dataset(recommendedItems(k,1),UserID));
            recommendedItemsFinal(x,1)=recommendedItems(k,1);
            recommendedItemsFinal(x,2)=recommendedItems(k,2);
            x=x+1;
        end
        k=k-1;
    end
    k=size(recommendedItemsFinal,1);
    for i=1:k
        %if recommendedItemsFinalSorted(recommendedItemsFinal(i,1),1)==0
        recommendedItemsFinalSorted(recommendedItemsFinal(i,1),1)=recommendedItemsFinal(i,1);
        recommendedItemsFinalSorted(recommendedItemsFinal(i,1),2)=recommendedItemsFinal(i,2);
        %end
    end
    recommendedItemsFinalSorted=sortrows(recommendedItemsFinalSorted,2);
    recommendedItemsFinalSorted=flipud(recommendedItemsFinalSorted);
    final_rows=size(recommendedItemsFinalSorted,1);
    index=1;
    for i=1:final_rows
        if (recommendedItemsFinalSorted(i,1)~=0 && recommendedItemsFinalSorted(i,2)~=0)
            recommend(index,1)=recommendedItemsFinalSorted(i,1);
            recommend(index,2)=recommendedItemsFinalSorted(i,2);
            index=index+1;
        end
    end
    % Top Ten items%
    topN=zeros(30,1);
    for i=1:30
        if recommendedItemsFinalSorted(i,1)~=0
            topN(i,1)=int64(recommendedItemsFinalSorted(i,1));
            %topN(i,2)=recommendedItemsFinalSorted(i,2)*100;
        end
    end
    xlswrite('finalOutput.xlsx',topN);
    toc
end